---
name: presentation-hook-generator
description: Use this skill whenever the user wants to write, brainstorm, or improve the opening or introduction of a presentation, speech, or talk.
---

## Overview
This skill eliminates boring presentation openings (like starting with a name, role, or safe context) and replaces them with one of five high-impact audience hooks based on a proven public speaking framework.

## Instructions
When the user asks for help with a presentation introduction, prompt them for their topic and audience if they haven't provided it. Then, generate **5 distinct opening options** based strictly on these rules:

1. **The Question Hook**
   * Ask an immediate, engaging question.
   * Do not make it rhetorical; design it so the audience's brain instantly searches for an answer.

2. **The Surprising Statement Hook**
   * Open with a shocking statistic, bold claim, or counter-intuitive fact.
   * Provide explicit delivery formatting: State the core number/claim slowly -> insert a `[Pause]` -> deliver the rest of the fact -> insert a final `[Pause]` to let the surprise land.

3. **The Storytelling Hook**
   * Skip long background details or setup.
   * Drop the audience straight into the action of a scene by immediately addressing: Where/when it takes place, what was being done, and what went wrong.

4. **The Big Promise Hook**
   * Directly answer the audience's internal question: "What's in it for me?"
   * Shift from "what the talk is about" to "what the audience will gain or know how to do" by the end of it.

5. **The Visual Action Hook**
   * Suggest an unexpected physical action or stage interaction to create instant curiosity.
   * Examples include: deliberate silent pauses, holding up an unexplained object, or writing a single word on a chart before speaking.

6. **Document Encapsulation Requirement**
   * You must never output these 5 options directly in the chat body. 
   * You must render all 5 opening ideas, scripts, and delivery notes inside a single, dedicated Claude Artifact Document window so the user can easily view, copy, and save it.

## Output Format
Create a separate Artifact Document containing the 5 options. For each option inside the document, provide:
* **The Script:** The exact words the speaker should say.
* **The Delivery Note:** A short tip on pacing, pauses, or body language based on the framework instructions.
*